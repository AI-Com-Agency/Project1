<?php do_action( 'lisner_user_listings_before' ); ?>

<?php echo do_shortcode( '[job_dashboard]' ); ?>

<?php do_action( 'lisner_user_listings_after' ); ?>
