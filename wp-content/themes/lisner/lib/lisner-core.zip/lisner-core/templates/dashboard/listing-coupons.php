<?php do_action( 'lisner_listing_coupons_before' ); ?>
<?php do_action( 'lisner_listing_coupons' ); ?>
<?php do_action( 'lisner_listing_coupons_after' ); ?>
