<?php do_action( 'lisner_listing_events_before' ); ?>
<?php do_action( 'lisner_listing_events' ); ?>
<?php do_action( 'lisner_listing_events_after' ); ?>
