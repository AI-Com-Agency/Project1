<?php do_action( 'lisner_booking_product_before' ); ?>
<?php do_action( 'lisner_booking_product' ); ?>
<?php do_action( 'lisner_booking_product_after' ); ?>
