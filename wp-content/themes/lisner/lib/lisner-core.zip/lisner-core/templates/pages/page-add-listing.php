<?php
/**
 * Template Name: Add Listing Page Template
 * Description: Page template for listing submission form
 *
 * @author pebas
 * @version 1.0.0
 */
?>
<?php get_header(); ?>
<?php the_post(); ?>
<?php the_content(); ?>
<?php get_footer(); ?>
