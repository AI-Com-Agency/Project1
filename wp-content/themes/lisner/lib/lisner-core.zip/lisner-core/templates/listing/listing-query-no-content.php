<?php
/**
 * Listing query part no content
 *
 * @author pebas
 * @version 1.0.0
 */
?>
<div class="container-fluid">
	<div class="row">
		<h1><?php esc_html_e( 'No listings found, try adjusting your search', 'lisner-core' ); ?></h1>
	</div>
</div>

