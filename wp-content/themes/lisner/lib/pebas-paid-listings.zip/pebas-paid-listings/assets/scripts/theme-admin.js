/*jslint browser: true*/
/*global $, jQuery, alert, tbm_data */
jQuery(document).ready(function ($) {
    "use strict";

    //$('.select2').select2();

});
