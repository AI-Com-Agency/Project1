<?php
/**
 * Load 3rd party compatibility tweaks.
 */
require_once( PEBAS_PL_DIR . '/includes/3rd-party/wpml.php' );
